import { test, expect } from "@playwright/test";
import { DEMO_USER, login } from "./utils";

// Covers catalog IDs: AUTH-1, AUTH-2, AUTH-3, AUTH-5

test.describe("Authentication & session", () => {
  test("AUTH-1: logs in with valid credentials and persists across reload", async ({ page }) => {
    await login(page);
    await expect(page.getByText(DEMO_USER.displayName, { exact: false }).first()).toBeVisible();

    await page.reload();
    await expect(page.getByText(DEMO_USER.displayName, { exact: false }).first()).toBeVisible({
      timeout: 10_000,
    });
  });

  test("AUTH-2: rejects an invalid password with a visible error, no session created", async ({ page }) => {
    await page.goto("/");
    const loginTrigger = page
      .getByRole("button", { name: /log in|sign in/i })
      .or(page.getByRole("link", { name: /log in|sign in/i }))
      .first();
    await loginTrigger.click();

    await page.getByLabel(/username/i).or(page.getByPlaceholder(/username/i)).fill(DEMO_USER.username);
    await page
      .getByLabel(/^password$/i)
      .or(page.getByPlaceholder(/password/i))
      .fill("definitely-the-wrong-password");
    await page
      .getByRole("dialog")
      .getByRole("button", { name: /log in|sign in/i })
      .or(page.getByRole("button", { name: /log in|sign in/i }).last())
      .click();

    await expect(page.getByText(/invalid|incorrect|failed|wrong/i).first()).toBeVisible({ timeout: 5_000 });
    await expect(page.getByText(DEMO_USER.displayName, { exact: false })).toHaveCount(0);
  });

  test("AUTH-3: logging out clears the session", async ({ page }) => {
    await login(page);

    const userMenu = page.getByRole("button", { name: new RegExp(DEMO_USER.displayName, "i") }).first();
    await userMenu.click();
    await page.getByRole("menuitem", { name: /log out|sign out/i }).or(page.getByRole("button", { name: /log out|sign out/i })).click();

    await expect(page.getByRole("button", { name: /log in|sign in/i }).first()).toBeVisible({ timeout: 5_000 });

    await page.reload();
    await expect(page.getByRole("button", { name: /log in|sign in/i }).first()).toBeVisible();
  });

  test("AUTH-5: an auth-gated action prompts login when logged out", async ({ page }) => {
    await page.goto("/");
    // Attempt to upvote the first visible post while logged out.
    const upvote = page.getByRole("button", { name: /upvote/i }).first();
    await upvote.click();

    const loginPromptVisible = await page
      .getByText(/log in|sign in/i)
      .first()
      .isVisible()
      .catch(() => false);

    expect(loginPromptVisible).toBeTruthy();
  });
});
