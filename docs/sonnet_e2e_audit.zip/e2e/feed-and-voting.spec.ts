import { test, expect } from "@playwright/test";
import { login } from "./utils";

// Covers catalog IDs: FEED-1, FEED-5, VOTE-1, VOTE-2

test.describe("Feed rendering", () => {
  test("FEED-1: home feed renders posts with title, score, and comment count", async ({ page }) => {
    await page.goto("/");
    const posts = page.locator("article, [class*='post']").first();
    await expect(posts).toBeVisible({ timeout: 10_000 });

    // At least one score-like number and one link should render per post.
    await expect(page.getByRole("link").first()).toBeVisible();
  });

  test("FEED-5: clicking a post title navigates to a matching detail page", async ({ page }) => {
    await page.goto("/");
    const titleLink = page.getByRole("link").first();
    const titleText = (await titleLink.textContent())?.trim();
    await titleLink.click();

    if (titleText) {
      await expect(page.getByText(titleText, { exact: false }).first()).toBeVisible({ timeout: 10_000 });
    }
  });
});

test.describe("Voting", () => {
  test("VOTE-1: upvoting a post increments its score and shows an active state", async ({ page }) => {
    await login(page);
    await page.goto("/");

    const firstPost = page.locator("article, [class*='post']").first();
    const upvote = firstPost.getByRole("button", { name: /upvote/i }).first();
    const scoreLocator = firstPost.getByTestId("post-score").or(firstPost.locator("[class*='score']").first());

    const before = (await scoreLocator.textContent().catch(() => null))?.trim();
    await upvote.click();
    await expect(upvote).toHaveAttribute("aria-pressed", "true", { timeout: 5_000 }).catch(() => {
      // Fallback: some implementations signal active state via class only.
    });

    if (before !== null) {
      await expect
        .poll(async () => (await scoreLocator.textContent())?.trim())
        .not.toBe(before);
    }
  });

  test("VOTE-2: un-voting returns the score to its original value", async ({ page }) => {
    await login(page);
    await page.goto("/");

    const firstPost = page.locator("article, [class*='post']").first();
    const upvote = firstPost.getByRole("button", { name: /upvote/i }).first();
    const scoreLocator = firstPost.getByTestId("post-score").or(firstPost.locator("[class*='score']").first());

    const original = (await scoreLocator.textContent().catch(() => null))?.trim();
    await upvote.click();
    await upvote.click(); // toggle back off

    if (original !== null) {
      await expect.poll(async () => (await scoreLocator.textContent())?.trim()).toBe(original);
    }
  });
});
