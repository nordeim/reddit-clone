import { test, expect } from "@playwright/test";

// Covers catalog IDs: NAV-1, NAV-3, NAV-4

test.describe("Navigation & routing", () => {
  test("NAV-1: primary nav links update the URL via client-side routing", async ({ page }) => {
    await page.goto("/");
    const [firstPostLink] = await page.getByRole("link").all();
    expect(firstPostLink).toBeTruthy();

    const homeUrl = page.url();
    // Click the first post-like link found and confirm the URL changed
    // without a full navigation (Playwright's `page.goto` wouldn't fire
    // for an internal <a> handled by the router, but we can at least
    // assert the URL diverges from the home route).
    const links = page.getByRole("link");
    const count = await links.count();
    let navigated = false;
    for (let i = 0; i < Math.min(count, 10); i++) {
      const href = await links.nth(i).getAttribute("href");
      if (href && href !== "/" && !href.startsWith("http") && !href.startsWith("#")) {
        await links.nth(i).click();
        navigated = true;
        break;
      }
    }
    expect(navigated).toBeTruthy();
    await expect(page).not.toHaveURL(homeUrl);
  });

  test("NAV-3: a post detail URL loads correctly on a cold, direct visit", async ({ page, context }) => {
    await page.goto("/");
    const postLink = page.getByRole("link").filter({ hasNotText: /^$/ }).first();
    const href = await postLink.getAttribute("href");
    test.skip(!href, "Could not locate a post link on the home feed to test a deep link with.");

    const freshPage = await context.newPage();
    await freshPage.goto(href!);
    await expect(freshPage.locator("body")).not.toBeEmpty();
    // A cold load of a real content route should not immediately bounce
    // to a generic not-found state.
    await expect(freshPage.getByText(/not found|doesn't exist|404/i)).toHaveCount(0);
    await freshPage.close();
  });

  test("NAV-4: an unknown route shows an explicit not-found state", async ({ page }) => {
    await page.goto("/this-route-should-not-exist-e2e-check");
    await expect(page.getByText(/not found|doesn't exist|404|nothing here/i).first()).toBeVisible({
      timeout: 5_000,
    });
  });
});
