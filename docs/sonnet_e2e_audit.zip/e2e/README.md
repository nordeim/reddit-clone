# Embers E2E suite (Playwright)

Automated coverage for the highest-priority cases in the QA console's test
catalog, run against the **live** deployment at
`https://reddit.jesspete.shop/`.

## Important — read before running

These specs were authored **without executing them against the live DOM**
(this authoring environment has no browser-automation runner, only a
static HTTP fetch of the served HTML shell). Locators deliberately favor
resilient, semantic queries (`getByRole`, `getByLabel`, `getByText` with
case-insensitive regex) over brittle CSS/testid guesses, but they are
**Reasoned, not Verified** — expect to adjust a handful of selectors after
the first real run, and update this note once confirmed.

## Setup

```bash
npx playwright install --with-deps
```

## Run

```bash
npx playwright test            # all projects (desktop Chrome/WebKit, mobile Chrome)
npx playwright test auth       # a single spec file
npx playwright show-report     # view the HTML report after a run
```

## Test data

Uses the demo account documented in the QA console:

| Field    | Value       |
| -------- | ----------- |
| Username | `you`       |
| Password | `embers-demo` |

Tests that create posts/comments prefix content with a `[e2e]` tag and a
run timestamp so generated data is identifiable and safe to clean up; they
do not assume a clean database and avoid depending on exact pre-existing
seed content beyond "at least one post/community exists".

## Files

| File | Catalog IDs covered |
| --- | --- |
| `auth.spec.ts` | AUTH-1, AUTH-2, AUTH-3, AUTH-5 |
| `navigation.spec.ts` | NAV-1, NAV-3, NAV-4 |
| `feed-and-voting.spec.ts` | FEED-1, FEED-5, VOTE-1, VOTE-2 |
| `comments.spec.ts` | COM-1, COM-7, COM-8 |
| `accessibility-and-responsive.spec.ts` | A11Y-1, A11Y-3, RESP-1 |

Remaining catalog items (search, communities, notifications, profile,
theme persistence, security probes, etc.) are documented in the QA
console's interactive checklist for manual execution or future automation.
