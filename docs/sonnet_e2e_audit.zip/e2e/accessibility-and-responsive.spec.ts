import { test, expect, devices } from "@playwright/test";

// Covers catalog IDs: A11Y-1, A11Y-3, RESP-1

test.describe("Accessibility", () => {
  test("A11Y-1: a skip-to-content link is reachable as the first Tab stop", async ({ page }) => {
    await page.goto("/");
    await page.keyboard.press("Tab");
    const active = await page.evaluate(() => {
      const el = document.activeElement;
      return el ? { tag: el.tagName, text: el.textContent?.trim().toLowerCase() } : null;
    });
    expect(active?.text ?? "").toMatch(/skip/);
  });

  test("A11Y-3: icon-only controls (vote buttons) have accessible names", async ({ page }) => {
    await page.goto("/");
    const upvote = page.getByRole("button", { name: /upvote/i }).first();
    await expect(upvote).toBeVisible();
    const accessibleName = await upvote.getAttribute("aria-label");
    const text = await upvote.textContent();
    expect((accessibleName ?? text ?? "").trim().length).toBeGreaterThan(0);
  });
});

test.describe("Responsive layout", () => {
  test.use({ ...devices["iPhone SE"] });

  test("RESP-1: no horizontal overflow on a 375px-class viewport", async ({ page }) => {
    await page.goto("/");
    const hasOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    );
    expect(hasOverflow).toBeFalsy();
  });
});
