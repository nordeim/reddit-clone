import { test, expect } from "@playwright/test";
import { login, uniqueTag } from "./utils";

// Covers catalog IDs: COM-1, COM-7, COM-8

test.describe("Comments", () => {
  test.beforeEach(async ({ page }) => {
    await login(page);
    await page.goto("/");
    const titleLink = page.getByRole("link").first();
    await titleLink.click();
  });

  test("COM-1: posting a top-level comment appears in the thread", async ({ page }) => {
    const commentBox = page.getByPlaceholder(/comment|what are your thoughts/i).or(page.getByRole("textbox").last());
    const text = uniqueTag("comment");
    await commentBox.fill(text);

    await page.getByRole("button", { name: /^comment$|^reply$|^post$|^submit$/i }).last().click();

    await expect(page.getByText(text, { exact: false })).toBeVisible({ timeout: 10_000 });
  });

  test("COM-7: an empty comment cannot be submitted", async ({ page }) => {
    const commentBox = page.getByPlaceholder(/comment|what are your thoughts/i).or(page.getByRole("textbox").last());
    await commentBox.fill("   ");

    const submit = page.getByRole("button", { name: /^comment$|^reply$|^post$|^submit$/i }).last();
    // Either the control is disabled for blank input, or clicking it
    // produces no new empty comment node — assert the safer of the two
    // depending on what's actually enabled.
    const isDisabled = await submit.isDisabled().catch(() => false);
    if (!isDisabled) {
      const before = await page.locator("body").innerText();
      await submit.click({ trial: false }).catch(() => {});
      const after = await page.locator("body").innerText();
      expect(after.length - before.length).toBeLessThan(5);
    } else {
      expect(isDisabled).toBeTruthy();
    }
  });

  test("COM-8: an injected script payload renders as inert text, not executable markup", async ({ page }) => {
    const payload = `${uniqueTag("xss")} <script>window.__e2eXssFired = true;</script>`;
    const commentBox = page.getByPlaceholder(/comment|what are your thoughts/i).or(page.getByRole("textbox").last());
    await commentBox.fill(payload);
    await page.getByRole("button", { name: /^comment$|^reply$|^post$|^submit$/i }).last().click();

    await page.waitForTimeout(1000);
    const fired = await page.evaluate(() => (window as unknown as Record<string, unknown>).__e2eXssFired);
    expect(fired).toBeFalsy();
  });
});
