import { type Page, expect } from "@playwright/test";

export const DEMO_USER = {
  username: "you",
  password: "embers-demo",
  displayName: "You",
  userId: "u-me",
};

/**
 * Best-effort login helper using semantic locators. Not verified against
 * the live DOM (see e2e/README.md) — if the trigger/field names differ
 * from what's guessed here, update the regexes below in one place rather
 * than in every spec.
 */
export async function login(page: Page, username = DEMO_USER.username, password = DEMO_USER.password) {
  await page.goto("/");

  const loginTrigger = page
    .getByRole("button", { name: /log in|sign in/i })
    .or(page.getByRole("link", { name: /log in|sign in/i }))
    .first();
  await loginTrigger.click();

  const usernameField = page
    .getByLabel(/username/i)
    .or(page.getByPlaceholder(/username/i));
  await usernameField.fill(username);

  const passwordField = page
    .getByLabel(/^password$/i)
    .or(page.getByPlaceholder(/password/i));
  await passwordField.fill(password);

  await page
    .getByRole("dialog")
    .getByRole("button", { name: /log in|sign in/i })
    .or(page.getByRole("button", { name: /log in|sign in/i }).last())
    .click();

  await expect(page.getByText(DEMO_USER.displayName, { exact: false }).first()).toBeVisible({
    timeout: 10_000,
  });
}

export function uniqueTag(prefix: string) {
  return `[e2e] ${prefix} ${new Date().toISOString()}`;
}
