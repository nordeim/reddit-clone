import { defineConfig, devices } from "@playwright/test";

/**
 * Playwright config for the E2E suite in `e2e/` that exercises the live
 * target application at https://reddit.jesspete.shop/. This is a
 * standalone automation project colocated with the QA console — it is
 * NOT part of the Vite app build/bundle.
 *
 * Run with:
 *   npx playwright install --with-deps
 *   npx playwright test
 */
export default defineConfig({
  testDir: "./e2e",
  fullyParallel: false, // shared demo account -> avoid cross-test state races
  retries: 1,
  reporter: [["html", { open: "never" }], ["list"]],
  use: {
    baseURL: "https://reddit.jesspete.shop",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: [
    { name: "chromium-desktop", use: { ...devices["Desktop Chrome"] } },
    { name: "webkit-desktop", use: { ...devices["Desktop Safari"] } },
    { name: "mobile-chrome", use: { ...devices["Pixel 7"] } },
  ],
});
