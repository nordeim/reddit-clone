import { useCallback, useEffect, useState } from "react";
import type { TestStatus } from "../types";

const STORAGE_KEY = "embers-qa-run-state";

type RunState = Record<string, TestStatus>;

function loadInitialState(): RunState {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? (parsed as RunState) : {};
  } catch {
    // Storage unavailable or corrupt — start from a clean run, same
    // fail-safe pattern the target site itself uses for theme state.
    return {};
  }
}

export function useTestRunState() {
  const [runState, setRunState] = useState<RunState>(loadInitialState);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(runState));
    } catch {
      // Ignore persistence failures (private browsing / quota) — the
      // session still works, it just won't survive a reload.
    }
  }, [runState]);

  const setStatus = useCallback((id: string, status: TestStatus) => {
    setRunState((prev) => ({ ...prev, [id]: status }));
  }, []);

  const resetAll = useCallback(() => setRunState({}), []);

  const getStatus = useCallback(
    (id: string): TestStatus => runState[id] ?? "not-run",
    [runState],
  );

  return { runState, setStatus, resetAll, getStatus };
}
