export type Priority = "critical" | "high" | "medium" | "low";

export type TestStatus = "not-run" | "pass" | "fail" | "blocked";

export type FeatureArea =
  | "Authentication & Session"
  | "Navigation & Routing"
  | "Feed & Sorting"
  | "Post Creation"
  | "Post Detail"
  | "Voting"
  | "Comments"
  | "Communities (Subreddits)"
  | "Search"
  | "User Profile"
  | "Settings & Theme"
  | "Notifications"
  | "Responsive & Mobile"
  | "Accessibility"
  | "Performance & Resilience"
  | "Security";

export interface TestCase {
  id: string;
  area: FeatureArea;
  title: string;
  priority: Priority;
  steps: string[];
  expected: string;
  notes?: string;
}

export type FindingSeverity = "critical" | "high" | "medium" | "low" | "info";

export interface StaticFinding {
  id: string;
  title: string;
  severity: FindingSeverity;
  evidence: string;
  impact: string;
  recommendation: string;
}
