import type { StaticFinding } from "../types";

/**
 * These findings come from a direct HTTP fetch + inspection of the raw
 * document served at https://reddit.jesspete.shop/ (view-source level,
 * no JS execution). They are the only claims in this app backed by
 * direct evidence rather than inferred test design — everything else in
 * the catalog is a planned check, not a result.
 */
export const staticFindings: StaticFinding[] = [
  {
    id: "SF-1",
    title: "Entire app ships as one inlined script — no code splitting",
    severity: "medium",
    evidence:
      "The full React + app bundle (React 19.2.6, app logic, all routes) is inlined as a single <script type=\"module\"> in index.html rather than referencing hashed, cacheable chunks (consistent with a single-file Vite build).",
    impact:
      "Every visit re-downloads the entire application on any index.html cache miss; there is no route-based code splitting, and CDN/browser caching of JS separately from HTML is not possible. This increases first-load payload as the app grows.",
    recommendation:
      "Move to standard multi-chunk Vite output with hashed filenames and long-lived cache headers on assets; keep only a small bootstrap inline.",
  },
  {
    id: "SF-2",
    title: "No meta description or Open Graph/Twitter card tags",
    severity: "medium",
    evidence:
      "<head> contains only charset, viewport, and <title>embers — a Reddit-style community feed</title> — no <meta name=\"description\">, og:*, or twitter:* tags.",
    impact:
      "Links shared to the site on social platforms or in chat apps will render with no preview text/image, and search engines have no description to display in results.",
    recommendation:
      "Add a static meta description and OG/Twitter tags in index.html, and consider per-route title/description updates via document.title + a head-management approach for post/subreddit pages.",
  },
  {
    id: "SF-3",
    title: "Single static <title> for all routes",
    severity: "low",
    evidence:
      "The document title is hardcoded to \"embers — a Reddit-style community feed\" in the HTML shell; whether it updates per post/subreddit/profile page can only be confirmed at runtime.",
    impact:
      "If the title is never updated client-side, browser tabs, history, and bookmarks are indistinguishable across pages, hurting usability and SEO.",
    recommendation:
      "Verify at runtime (see PERF-TITLE test case) and set document.title on route change if not already done.",
  },
  {
    id: "SF-4",
    title: "No <noscript> fallback",
    severity: "low",
    evidence:
      "<body> only contains <div id=\"root\"></div> and module scripts; there is no <noscript> element.",
    impact:
      "Users with JavaScript disabled or blocked (corporate policies, some accessibility tooling, script errors) see a completely blank page with no explanation.",
    recommendation:
      "Add a brief <noscript> message explaining that JavaScript is required.",
  },
  {
    id: "SF-5",
    title: "Theme persistence uses a documented, inspectable localStorage key",
    severity: "info",
    evidence:
      "An inline bootstrap script reads localStorage key \"reddit-clone-state\", expects shape { state: { theme } }, and adds a `.dark` class to <html> before React mounts, wrapped in try/catch with a silent fallback to light mode.",
    impact:
      "Positive: avoids a flash-of-incorrect-theme and fails safe (light mode) if storage is unavailable or corrupted (e.g. private browsing). This also reveals the store key useful for E2E test fixtures (pre-seeding auth/theme state).",
    recommendation:
      "No action required; good defensive pattern. Automated tests can use this key to seed dark-mode/login state directly via localStorage instead of clicking through UI every run.",
  },
  {
    id: "SF-6",
    title: "Focus-visible and skip-link styles are present in shipped CSS",
    severity: "info",
    evidence:
      "Compiled CSS includes a `.skip-link` rule (hidden off-screen until :focus) and a global `:focus-visible` outline rule using the orange accent color, plus a prefers-reduced-motion override.",
    impact:
      "Positive signal for baseline keyboard-accessibility and motion-sensitivity support, but presence of CSS does not confirm an actual skip-link element exists in the DOM or that it points to a valid main-content anchor — must be confirmed at runtime.",
    recommendation:
      "Verify at runtime (see A11Y-1 test case) that a skip link is reachable as the first Tab stop and lands focus on main content.",
  },
  {
    id: "SF-7",
    title: "Cloudflare Web Analytics beacon present, no other third-party trackers detected in HTML",
    severity: "info",
    evidence:
      "A single <script> loads static.cloudflareinsights.com/beacon.min.js with a data-cf-beacon token; no other analytics/ad/tracking scripts appear in the served HTML.",
    impact:
      "Minimal-footprint analytics choice from a data-minimization standpoint; no PII observed being collected client-side from the shell alone.",
    recommendation:
      "No action required from static inspection; confirm no additional trackers are injected at runtime.",
  },
];
