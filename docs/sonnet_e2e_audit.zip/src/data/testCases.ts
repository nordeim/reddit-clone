import type { TestCase } from "../types";

export const testCases: TestCase[] = [
  // ---------------------------------------------------------------- Auth
  {
    id: "AUTH-1",
    area: "Authentication & Session",
    title: "Log in with valid credentials",
    priority: "critical",
    steps: [
      "Navigate to https://reddit.jesspete.shop/",
      "Open the login form (header 'Log In' action)",
      "Enter username 'you' and password 'embers-demo'",
      "Submit",
    ],
    expected:
      "User is authenticated, header shows display name 'You', session persists across a page reload without re-entering credentials.",
  },
  {
    id: "AUTH-2",
    area: "Authentication & Session",
    title: "Log in with invalid password is rejected with a clear error",
    priority: "high",
    steps: ["Attempt login with username 'you' and an incorrect password"],
    expected:
      "Login is rejected, an inline, specific error message is shown (not a generic crash or silent no-op), password field is not silently cleared without explanation, and no session is created.",
  },
  {
    id: "AUTH-3",
    area: "Authentication & Session",
    title: "Log out clears session and protected UI",
    priority: "critical",
    steps: ["While logged in as 'you', trigger logout from the user menu"],
    expected:
      "Session is cleared, vote/comment/post-creation controls that require auth are hidden or disabled, and a reload does not silently restore the authenticated session.",
  },
  {
    id: "AUTH-4",
    area: "Authentication & Session",
    title: "Session survives a hard reload and new tab",
    priority: "high",
    steps: [
      "Log in as 'you'",
      "Hard-reload the page",
      "Open the site in a second tab of the same browser",
    ],
    expected:
      "Authenticated state persists after reload and is shared with the new tab (or the app's documented session model is otherwise consistent).",
  },
  {
    id: "AUTH-5",
    area: "Authentication & Session",
    title: "Auth-gated actions redirect/prompt when logged out",
    priority: "high",
    steps: [
      "Log out",
      "Attempt to upvote a post, comment, or create a post",
    ],
    expected:
      "User is prompted to log in (modal or redirect) rather than the action failing silently or throwing an unhandled error.",
  },
  {
    id: "AUTH-6",
    area: "Authentication & Session",
    title: "Empty/whitespace-only credentials are rejected client-side",
    priority: "medium",
    steps: ["Submit the login form with empty username and password fields"],
    expected:
      "Form shows validation messaging and does not fire a network request with empty credentials.",
  },

  // ---------------------------------------------------------- Navigation
  {
    id: "NAV-1",
    area: "Navigation & Routing",
    title: "Primary navigation links route correctly",
    priority: "critical",
    steps: [
      "From the home feed, click each primary nav item (Home, Popular/All, a community link, profile link)",
    ],
    expected:
      "Each click updates both the URL and the rendered view; no full-page reload occurs for internal links (SPA routing).",
  },
  {
    id: "NAV-2",
    area: "Navigation & Routing",
    title: "Browser back/forward works after client-side navigation",
    priority: "high",
    steps: [
      "Navigate Home → a post → a community page",
      "Press browser Back twice, then Forward twice",
    ],
    expected:
      "Back/Forward restores the correct prior views and scroll-appropriate state without errors or blank screens.",
  },
  {
    id: "NAV-3",
    area: "Navigation & Routing",
    title: "Direct URL entry / deep link / refresh on a sub-route",
    priority: "critical",
    steps: [
      "Copy the URL of a specific post's detail page",
      "Open it in a fresh browser tab (no prior SPA navigation) and also hard-refresh on that URL",
    ],
    expected:
      "The correct post loads directly from a cold load; the app does not require navigating from the home page first (no client-routing-only 404).",
  },
  {
    id: "NAV-4",
    area: "Navigation & Routing",
    title: "Unknown route shows a proper 404 / not-found state",
    priority: "medium",
    steps: ["Navigate to an obviously invalid path, e.g. /this-page-does-not-exist"],
    expected:
      "A clear not-found page or message is shown with a way back to the home feed, rather than a blank page or unhandled error.",
  },
  {
    id: "NAV-5",
    area: "Navigation & Routing",
    title: "Logo click returns to home feed from any page",
    priority: "low",
    steps: ["From a deep page (post detail, profile), click the site logo/wordmark"],
    expected: "Navigates back to the home feed.",
  },

  // -------------------------------------------------------------- Feed
  {
    id: "FEED-1",
    area: "Feed & Sorting",
    title: "Home feed loads posts with required metadata",
    priority: "critical",
    steps: ["Load the home feed"],
    expected:
      "Each post card shows title, subreddit/community, author, relative timestamp, score, and comment count, with no missing/undefined values.",
  },
  {
    id: "FEED-2",
    area: "Feed & Sorting",
    title: "Sort options (Hot/New/Top/Rising or equivalent) change order",
    priority: "high",
    steps: ["Switch between each available sort control on the feed"],
    expected:
      "Post order visibly changes to match the selected sort and the active sort is indicated in the UI.",
  },
  {
    id: "FEED-3",
    area: "Feed & Sorting",
    title: "Pagination / infinite scroll loads additional posts without duplicates",
    priority: "high",
    steps: [
      "Scroll to the bottom of the feed (or click 'load more' if present) repeatedly",
    ],
    expected:
      "Additional unique posts load; no duplicate post IDs appear; loading indicator shows during fetch and clears after.",
  },
  {
    id: "FEED-4",
    area: "Feed & Sorting",
    title: "Empty feed state is handled",
    priority: "medium",
    steps: [
      "Trigger a feed/filter combination expected to return zero results (e.g. a brand-new empty community)",
    ],
    expected:
      "An explicit empty-state message is shown, not a blank area or infinite spinner.",
  },
  {
    id: "FEED-5",
    area: "Feed & Sorting",
    title: "Post card links to correct post detail page",
    priority: "critical",
    steps: ["Click several different post titles from the feed"],
    expected: "Each click opens the matching post's detail view, not a mismatched or stale post.",
  },

  // ------------------------------------------------------ Post Creation
  {
    id: "POST-1",
    area: "Post Creation",
    title: "Create a text post with title and body",
    priority: "critical",
    steps: [
      "Log in as 'you'",
      "Open the create-post flow",
      "Enter a title and body text, select a community, submit",
    ],
    expected:
      "Post is created, user is routed to it (or it appears in the feed), and all entered fields render correctly.",
  },
  {
    id: "POST-2",
    area: "Post Creation",
    title: "Title is required; empty title is blocked with feedback",
    priority: "high",
    steps: ["Attempt to submit the create-post form with an empty title"],
    expected: "Submission is blocked client-side with a visible validation message.",
  },
  {
    id: "POST-3",
    area: "Post Creation",
    title: "Title length limit is enforced and communicated",
    priority: "medium",
    steps: ["Enter a very long title (300+ characters) into the title field"],
    expected:
      "Either input is capped at a documented max length with a visible counter, or an explicit error is shown on submit — not a silent truncation or backend crash.",
  },
  {
    id: "POST-4",
    area: "Post Creation",
    title: "Link/image post type (if supported) validates URL format",
    priority: "medium",
    steps: ["Select a link/image post type and enter a malformed URL"],
    expected: "A validation error is shown rather than creating a broken post.",
  },
  {
    id: "POST-5",
    area: "Post Creation",
    title: "Community selector only allows posting to a valid, existing community",
    priority: "medium",
    steps: ["Open the community selector in the create-post flow"],
    expected: "Only real, existing communities are selectable/typeaheaded; free text cannot silently create an invalid reference.",
  },
  {
    id: "POST-6",
    area: "Post Creation",
    title: "Attempting to create a post while logged out",
    priority: "high",
    steps: ["Log out, then navigate directly to the create-post route"],
    expected: "User is redirected to login or shown a clear auth-required prompt instead of a broken form.",
  },

  // -------------------------------------------------------- Post Detail
  {
    id: "PDET-1",
    area: "Post Detail",
    title: "Post detail page renders full content and metadata",
    priority: "critical",
    steps: ["Open a post's detail page"],
    expected:
      "Full title, body/media, author, community, timestamp, score, and comment count render without truncation artifacts from the feed card.",
  },
  {
    id: "PDET-2",
    area: "Post Detail",
    title: "Permalink is copyable and correct",
    priority: "medium",
    steps: ["Use the 'share'/'copy link' action on a post"],
    expected: "The copied URL, when opened fresh, loads the exact same post (see NAV-3).",
  },
  {
    id: "PDET-3",
    area: "Post Detail",
    title: "Author and community links from post detail navigate correctly",
    priority: "medium",
    steps: ["Click the author name and the community name on a post detail page"],
    expected: "Each navigates to the correct profile/community page respectively.",
  },
  {
    id: "PDET-4",
    area: "Post Detail",
    title: "Non-existent post ID shows not-found, not a crash",
    priority: "high",
    steps: ["Navigate to a post detail URL with a fabricated/invalid ID"],
    expected: "A graceful 'post not found' state is shown; no unhandled exception or blank white screen.",
  },

  // ------------------------------------------------------------- Voting
  {
    id: "VOTE-1",
    area: "Voting",
    title: "Upvote increments score and shows active state",
    priority: "critical",
    steps: ["Log in, upvote a post you have not previously voted on"],
    expected: "Score increases by 1 immediately, upvote control shows an active/highlighted state.",
  },
  {
    id: "VOTE-2",
    area: "Voting",
    title: "Toggling the same vote off returns score to original",
    priority: "high",
    steps: ["Upvote a post, then click upvote again to un-vote"],
    expected: "Score returns to its pre-vote value and the active state clears.",
  },
  {
    id: "VOTE-3",
    area: "Voting",
    title: "Switching from upvote to downvote moves score by 2",
    priority: "high",
    steps: ["Upvote a post, then click downvote on the same post"],
    expected: "Score decreases by 2 total from the upvoted value, downvote shows active state, upvote clears.",
  },
  {
    id: "VOTE-4",
    area: "Voting",
    title: "Vote state persists across reload",
    priority: "medium",
    steps: ["Vote on a post, reload the page, revisit the same post"],
    expected: "The vote indicator still reflects the user's prior vote.",
  },
  {
    id: "VOTE-5",
    area: "Voting",
    title: "Comment voting behaves the same as post voting",
    priority: "high",
    steps: ["Repeat VOTE-1 through VOTE-3 on a comment instead of a post"],
    expected: "Comment score and vote-state UI behave consistently with post voting.",
  },
  {
    id: "VOTE-6",
    area: "Voting",
    title: "Rapid repeated vote clicks do not desync score",
    priority: "medium",
    steps: ["Click upvote/downvote on the same post rapidly (5+ clicks in under a second)"],
    expected: "Final displayed score matches the final logical vote state after requests settle — no drift from race conditions.",
  },

  // ----------------------------------------------------------- Comments
  {
    id: "COM-1",
    area: "Comments",
    title: "Post a top-level comment",
    priority: "critical",
    steps: ["Open a post, enter text in the comment box, submit"],
    expected: "Comment appears in the thread with correct author, timestamp, and body — without requiring a manual page reload.",
  },
  {
    id: "COM-2",
    area: "Comments",
    title: "Reply to a comment creates a nested thread",
    priority: "high",
    steps: ["Reply to an existing comment"],
    expected: "Reply is visually nested under its parent with correct indentation/threading.",
  },
  {
    id: "COM-3",
    area: "Comments",
    title: "Edit own comment",
    priority: "medium",
    steps: ["Edit a comment you authored"],
    expected: "Updated text is saved and displayed; an 'edited' indicator appears if the app documents that convention.",
  },
  {
    id: "COM-4",
    area: "Comments",
    title: "Delete own comment",
    priority: "medium",
    steps: ["Delete a comment you authored that has no replies, and separately one that has replies"],
    expected:
      "Comment is removed or replaced with a '[deleted]' placeholder; if it has replies, the thread structure below it is preserved.",
  },
  {
    id: "COM-5",
    area: "Comments",
    title: "Cannot edit or delete another user's comment",
    priority: "high",
    steps: ["View a comment authored by a different user"],
    expected: "No edit/delete controls are exposed for comments the current user does not own.",
  },
  {
    id: "COM-6",
    area: "Comments",
    title: "Collapse/expand a comment thread",
    priority: "low",
    steps: ["Click the collapse control on a comment with replies"],
    expected: "The subtree hides/shows correctly and the collapse state is visually clear.",
  },
  {
    id: "COM-7",
    area: "Comments",
    title: "Empty comment cannot be submitted",
    priority: "medium",
    steps: ["Submit the comment box with no text (or only whitespace)"],
    expected: "Submission is blocked with feedback; no empty comment is created.",
  },
  {
    id: "COM-8",
    area: "Comments",
    title: "Comment box rejects script/HTML injection as literal text",
    priority: "high",
    steps: [
      "Submit a comment containing '<script>alert(1)</script>' and '<img src=x onerror=alert(1)>'",
    ],
    expected:
      "Content is rendered as inert, escaped text (or stripped) — no script executes and no injected markup alters the page.",
  },

  // ------------------------------------------------------- Communities
  {
    id: "SUB-1",
    area: "Communities (Subreddits)",
    title: "Community page shows its own posts, name, and description",
    priority: "critical",
    steps: ["Navigate to a specific community's page"],
    expected: "Only posts belonging to that community are listed, alongside its name/description/icon and member count if present.",
  },
  {
    id: "SUB-2",
    area: "Communities (Subreddits)",
    title: "Join / leave a community toggles state and feed membership",
    priority: "high",
    steps: ["While logged in, click Join on a community, then Leave"],
    expected:
      "Button state toggles correctly, subscriber count updates accordingly, and a 'Home'/subscribed feed reflects membership if such a feed exists.",
  },
  {
    id: "SUB-3",
    area: "Communities (Subreddits)",
    title: "Create a new community (if supported)",
    priority: "medium",
    steps: ["Use the create-community flow with a unique name"],
    expected: "Community is created and immediately navigable; duplicate names are rejected with a clear message.",
  },
  {
    id: "SUB-4",
    area: "Communities (Subreddits)",
    title: "Non-existent community route shows not-found",
    priority: "medium",
    steps: ["Navigate to a community URL with a name that does not exist"],
    expected: "Graceful not-found state, not a crash or empty infinite loader.",
  },

  // ------------------------------------------------------------ Search
  {
    id: "SRCH-1",
    area: "Search",
    title: "Search returns relevant results for a known post/community title",
    priority: "high",
    steps: ["Use the search bar with a term known to match an existing post or community"],
    expected: "Matching results are shown, correctly linking to the matched post/community.",
  },
  {
    id: "SRCH-2",
    area: "Search",
    title: "Search with no matches shows an explicit empty state",
    priority: "medium",
    steps: ["Search for a nonsense string unlikely to match anything"],
    expected: "A clear 'no results' message appears instead of a blank panel.",
  },
  {
    id: "SRCH-3",
    area: "Search",
    title: "Search input is debounced / does not spam requests per keystroke",
    priority: "low",
    steps: ["Type a multi-character query quickly into the search box"],
    expected: "Network requests are debounced/throttled rather than firing on every keystroke.",
  },
  {
    id: "SRCH-4",
    area: "Search",
    title: "Search query is escaped and cannot break the results page",
    priority: "medium",
    steps: ["Search using special characters and a raw HTML/script payload"],
    expected: "Input is treated as literal text; no script executes and no layout break occurs.",
  },

  // -------------------------------------------------------------- Profile
  {
    id: "PROF-1",
    area: "User Profile",
    title: "Own profile shows correct identity and activity",
    priority: "high",
    steps: ["Log in as 'you' and open the profile page"],
    expected: "Display name 'You', user id reference consistent with 'u-me', and post/comment history for that account are shown.",
  },
  {
    id: "PROF-2",
    area: "User Profile",
    title: "Karma/score totals reflect actual vote activity",
    priority: "medium",
    steps: ["Compare displayed karma against the sum of scores on the account's own posts/comments where derivable"],
    expected: "Numbers are internally consistent, not a static placeholder value.",
  },
  {
    id: "PROF-3",
    area: "User Profile",
    title: "Visiting another user's profile hides owner-only controls",
    priority: "high",
    steps: ["Open the profile page of a different user than the one logged in"],
    expected: "No edit-profile/account-settings controls are shown for a non-owned profile.",
  },
  {
    id: "PROF-4",
    area: "User Profile",
    title: "Profile post/comment tabs paginate or scroll correctly",
    priority: "low",
    steps: ["Switch between a profile's Posts and Comments tabs"],
    expected: "Each tab loads the correct, distinct content set without leaking items from the other tab.",
  },

  // ------------------------------------------------------ Settings/Theme
  {
    id: "SET-1",
    area: "Settings & Theme",
    title: "Dark/light theme toggle updates UI immediately",
    priority: "high",
    steps: ["Toggle the theme control"],
    expected: "All major surfaces (background, text, cards, nav) switch palette immediately with no unstyled flash.",
  },
  {
    id: "SET-2",
    area: "Settings & Theme",
    title: "Theme choice persists across reload",
    priority: "medium",
    steps: ["Set dark mode, reload the page"],
    expected:
      "Page loads directly in dark mode with no flash of light theme before it applies (see static finding SF-5, which confirms the bootstrap mechanism exists — this case verifies it visually).",
  },
  {
    id: "SET-3",
    area: "Settings & Theme",
    title: "Theme preference works in a fresh private/incognito window",
    priority: "low",
    steps: ["In a private window with no prior storage, load the site and toggle theme, then reload"],
    expected: "Theme still applies and persists within that private session; if storage is blocked, app falls back to light mode without erroring (per SF-5).",
  },

  // ---------------------------------------------------------- Notif.
  {
    id: "NOTIF-1",
    area: "Notifications",
    title: "Receiving a reply/comment triggers a visible notification indicator",
    priority: "medium",
    steps: ["As user A, comment/reply on user B's post; log in as user B"],
    expected: "User B sees an unread notification indicator referencing the new activity.",
  },
  {
    id: "NOTIF-2",
    area: "Notifications",
    title: "Opening/reading notifications clears the unread count",
    priority: "low",
    steps: ["Open the notifications panel/page with unread items present"],
    expected: "Unread badge count clears or decrements appropriately after viewing.",
  },

  // --------------------------------------------------- Responsive
  {
    id: "RESP-1",
    area: "Responsive & Mobile",
    title: "Layout adapts correctly at 375px width (mobile)",
    priority: "critical",
    steps: ["Set viewport to 375x812 and load the home feed, a post, and the create-post flow"],
    expected: "No horizontal scroll/overflow, nav collapses to a mobile-appropriate pattern (hamburger/bottom nav), tap targets are at least ~44px.",
  },
  {
    id: "RESP-2",
    area: "Responsive & Mobile",
    title: "Layout adapts correctly at 768px width (tablet)",
    priority: "medium",
    steps: ["Set viewport to 768x1024 and repeat RESP-1 checks"],
    expected: "Layout uses available width sensibly; no obviously desktop-only or obviously mobile-only elements are stuck mid-breakpoint.",
  },
  {
    id: "RESP-3",
    area: "Responsive & Mobile",
    title: "Text and controls remain usable at 320px (small mobile)",
    priority: "medium",
    steps: ["Set viewport to 320x568 and load the home feed"],
    expected: "No text clipping/overlap, buttons remain tappable and legible.",
  },

  // --------------------------------------------------- Accessibility
  {
    id: "A11Y-1",
    area: "Accessibility",
    title: "Skip-to-content link is the first focusable element",
    priority: "high",
    steps: ["Load the home page and press Tab once before clicking anything"],
    expected:
      "A 'Skip to content' link becomes visible and focused first (CSS for this exists per SF-6); activating it moves focus into the main content region.",
  },
  {
    id: "A11Y-2",
    area: "Accessibility",
    title: "Full keyboard operability of core flows",
    priority: "critical",
    steps: ["Using only the keyboard, log in, open a post, upvote it, and post a comment"],
    expected: "Every interactive control involved is reachable via Tab/Shift+Tab and operable via Enter/Space, with a visible focus indicator at each step.",
  },
  {
    id: "A11Y-3",
    area: "Accessibility",
    title: "Images and icon-only buttons have accessible names",
    priority: "high",
    steps: ["Inspect accessible names for vote arrows, avatar images, and icon-only buttons (share, save, menu)"],
    expected: "Each has a non-empty accessible name (alt text or aria-label) — screen reader users are not left with 'button, button, button'.",
  },
  {
    id: "A11Y-4",
    area: "Accessibility",
    title: "Color contrast meets WCAG 2.2 AA in both light and dark themes",
    priority: "high",
    steps: ["Check text/background contrast ratios for body text, muted metadata text, and button labels in both themes"],
    expected: "Normal text ≥ 4.5:1, large text ≥ 3:1 in both themes, including muted 'zinc' secondary text colors.",
  },
  {
    id: "A11Y-5",
    area: "Accessibility",
    title: "Form fields have programmatically associated labels",
    priority: "medium",
    steps: ["Inspect the login, comment, and create-post form fields"],
    expected: "Every input has a <label for> or aria-label/aria-labelledby, not just placeholder text.",
  },
  {
    id: "A11Y-6",
    area: "Accessibility",
    title: "Reduced-motion preference is respected",
    priority: "low",
    steps: ["Enable 'prefers-reduced-motion: reduce' at the OS/browser level and reload"],
    expected: "Transitions/animations are minimized (a global override for this exists per shipped CSS) — confirm no motion-heavy interactions bypass it.",
  },

  // ---------------------------------------------- Performance/Resilience
  {
    id: "PERF-1",
    area: "Performance & Resilience",
    title: "Document title updates per route",
    priority: "medium",
    steps: ["Navigate to a post detail page and a community page, checking the browser tab title each time"],
    expected: "Title reflects the current page/post/community (see SF-3), not the static app-level default for every route.",
    notes: "Directly resolves the open question raised by static finding SF-3.",
  },
  {
    id: "PERF-2",
    area: "Performance & Resilience",
    title: "App recovers gracefully from a failed API request",
    priority: "high",
    steps: ["Simulate an offline/failed network condition while loading the feed or submitting a comment"],
    expected: "A visible error/retry affordance is shown; the UI does not hang on an infinite spinner or throw an unhandled promise rejection to a blank screen.",
  },
  {
    id: "PERF-3",
    area: "Performance & Resilience",
    title: "Buttons disable during in-flight async actions",
    priority: "medium",
    steps: ["Click Submit on login, post creation, and comment forms and immediately click again before the request resolves"],
    expected: "The control disables or debounces to prevent duplicate submissions (duplicate posts/comments).",
  },
  {
    id: "PERF-4",
    area: "Performance & Resilience",
    title: "Initial load performance is reasonable on a throttled connection",
    priority: "low",
    steps: ["Load the home feed under a simulated 'Slow 4G' network profile"],
    expected: "A loading state is visible quickly (not a blank white screen for multiple seconds), and time-to-interactive is reasonable given the single-bundle architecture noted in SF-1.",
  },

  // ------------------------------------------------------------- Security
  {
    id: "SEC-1",
    area: "Security",
    title: "Session/auth token is not exposed in the URL",
    priority: "high",
    steps: ["Log in and inspect the URL bar and browser history entries"],
    expected: "No session token, password, or credential appears in the URL at any point.",
  },
  {
    id: "SEC-2",
    area: "Security",
    title: "Client cannot vote/comment/post as another user by ID manipulation",
    priority: "critical",
    steps: [
      "While logged in as 'you', attempt to trigger an authenticated action and inspect/replay the underlying request with a different user id (e.g. via browser devtools)",
    ],
    expected: "Server-side authorization rejects mismatched identity; the client cannot act as another user by changing a client-supplied id.",
  },
  {
    id: "SEC-3",
    area: "Security",
    title: "Stored XSS is not possible via post title/body or comments",
    priority: "critical",
    steps: ["Create a post and a comment containing HTML/script payloads, then view them as a different logged-in user"],
    expected: "Payload renders as inert text for all viewers; no script executes for any user (extends COM-8 to persisted, cross-user viewing).",
  },
  {
    id: "SEC-4",
    area: "Security",
    title: "Password field is masked and not autocompleted insecurely",
    priority: "low",
    steps: ["Inspect the login password input"],
    expected: "Input type is 'password' (masked), and the field does not leak its value via autofill into unrelated fields.",
  },
];
