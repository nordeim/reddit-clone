import { useEffect, useMemo, useState } from "react";
import { testCases } from "./data/testCases";
import { useTestRunState } from "./hooks/useTestRunState";
import type { FeatureArea, Priority, TestStatus } from "./types";
import { TopBar } from "./components/TopBar";
import { MethodologyBanner } from "./components/MethodologyBanner";
import { CredentialsCard } from "./components/CredentialsCard";
import { SummaryStats } from "./components/SummaryStats";
import { Filters } from "./components/Filters";
import { FeatureGroup } from "./components/FeatureGroup";
import { StaticFindings } from "./components/StaticFindings";
import { AutomationPanel } from "./components/AutomationPanel";
import { ExportBar } from "./components/ExportBar";

const THEME_KEY = "embers-qa-theme";

function loadInitialTheme(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(THEME_KEY) === "dark";
  } catch {
    return false;
  }
}

const areas: FeatureArea[] = Array.from(new Set(testCases.map((c) => c.area)));

export default function App() {
  const [dark, setDark] = useState(loadInitialTheme);
  const [area, setArea] = useState<FeatureArea | "all">("all");
  const [priority, setPriority] = useState<Priority | "all">("all");
  const [status, setStatus] = useState<TestStatus | "all">("all");
  const [query, setQuery] = useState("");
  const { setStatus: setCaseStatus, getStatus, resetAll } = useTestRunState();

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try {
      window.localStorage.setItem(THEME_KEY, dark ? "dark" : "light");
    } catch {
      // Ignore persistence failures; theme still applies for this session.
    }
  }, [dark]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return testCases.filter((c) => {
      if (area !== "all" && c.area !== area) return false;
      if (priority !== "all" && c.priority !== priority) return false;
      if (status !== "all" && getStatus(c.id) !== status) return false;
      if (q) {
        const haystack = `${c.id} ${c.title} ${c.steps.join(" ")} ${c.expected}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [area, priority, status, query, getStatus]);

  const groupedAreas = useMemo(() => {
    const set = new Set(filtered.map((c) => c.area));
    return areas.filter((a) => set.has(a));
  }, [filtered]);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-100">
      <a
        href="#main-content"
        className="skip-link fixed left-2 top-2 z-50 -translate-y-16 rounded-md bg-orange-600 px-3 py-2 text-sm font-semibold text-white transition-transform focus:translate-y-0"
      >
        Skip to content
      </a>
      <TopBar dark={dark} onToggleDark={() => setDark((d) => !d)} />

      <main id="main-content" className="mx-auto max-w-7xl space-y-6 px-4 py-6 sm:px-6">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">
            E2E Test Plan — <span className="text-orange-600 dark:text-orange-400">reddit.jesspete.shop</span>
          </h1>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            {testCases.length} test cases across {areas.length} feature areas, plus static findings from
            direct source inspection.
          </p>
        </div>

        <MethodologyBanner />

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <CredentialsCard />
          <div className="lg:col-span-2">
            <SummaryStats cases={testCases} getStatus={getStatus} />
          </div>
        </div>

        <StaticFindings />
        <AutomationPanel />

        <div className="space-y-3 pt-2">
          <h2 className="text-lg font-bold tracking-tight text-zinc-900 dark:text-zinc-50">Test catalog</h2>
          <Filters
            areas={areas}
            area={area}
            onAreaChange={setArea}
            priority={priority}
            onPriorityChange={setPriority}
            status={status}
            onStatusChange={setStatus}
            query={query}
            onQueryChange={setQuery}
          />
          <ExportBar cases={testCases} getStatus={getStatus} onReset={resetAll} />

          {groupedAreas.length === 0 ? (
            <p className="rounded-xl border border-dashed border-zinc-300 bg-white px-4 py-8 text-center text-sm text-zinc-500 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-400">
              No test cases match the current filters.
            </p>
          ) : (
            groupedAreas.map((a) => (
              <FeatureGroup
                key={a}
                area={a}
                cases={filtered.filter((c) => c.area === a)}
                getStatus={getStatus}
                setStatus={setCaseStatus}
              />
            ))
          )}
        </div>

        <footer className="border-t border-zinc-200 py-6 text-xs text-zinc-400 dark:border-zinc-800 dark:text-zinc-600">
          Generated as a QA planning tool. Static findings are Verified (direct source evidence); every
          catalog entry is a planned check awaiting manual or automated execution — statuses are stored
          only in this browser's local storage.
        </footer>
      </main>
    </div>
  );
}
