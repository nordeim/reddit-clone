import { AlertTriangle, CheckCircle2 } from "lucide-react";

export function MethodologyBanner() {
  return (
    <div className="rounded-xl border border-amber-300/60 bg-amber-50 p-4 dark:border-amber-500/30 dark:bg-amber-500/10">
      <div className="flex gap-3">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden="true" />
        <div className="space-y-2 text-sm text-amber-900 dark:text-amber-200">
          <p className="font-semibold">Scope &amp; verification method — read before using this report</p>
          <p>
            This console was generated without a live browser-automation tool: the target site is a
            client-rendered single-page app, and only a static HTTP fetch of the served document was
            available. That fetch was used to extract the <strong>Verified findings</strong> below (real
            evidence from the shipped HTML/CSS/JS). Everything in the <strong>Test Catalog</strong> is a
            planned check, not an executed result — every case starts as <em>Not run</em>.
          </p>
          <p className="flex items-start gap-2">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" aria-hidden="true" />
            <span>
              To actually execute this plan: use the interactive checklist below while manually clicking
              through <code className="rounded bg-amber-100 px-1 py-0.5 dark:bg-amber-500/20">reddit.jesspete.shop</code>,
              or run the included Playwright suite in <code className="rounded bg-amber-100 px-1 py-0.5 dark:bg-amber-500/20">e2e/</code> (commands in the Automation panel).
              Selectors in that suite are written defensively against typical Reddit-clone markup and role
              semantics, but were not verified against the live DOM — treat them as a starting scaffold to
              adjust after a first run.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
