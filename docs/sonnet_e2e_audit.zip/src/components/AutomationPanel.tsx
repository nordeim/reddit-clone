import { Terminal } from "lucide-react";

const commands = [
  "npx playwright install --with-deps",
  "npx playwright test --config=playwright.config.ts",
  "npx playwright show-report",
];

export function AutomationPanel() {
  return (
    <section className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
      <div className="flex items-center gap-2 border-b border-zinc-100 px-4 py-3 dark:border-zinc-800">
        <Terminal className="h-4 w-4 text-orange-600 dark:text-orange-400" aria-hidden="true" />
        <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">Run the automated suite</h3>
      </div>
      <div className="space-y-3 px-4 py-3 text-sm text-zinc-600 dark:text-zinc-400">
        <p>
          A Playwright suite covering the highest-priority cases in this catalog lives in{" "}
          <code className="rounded bg-zinc-100 px-1 py-0.5 text-xs dark:bg-zinc-800">e2e/</code> at the
          project root, pointed at <code className="rounded bg-zinc-100 px-1 py-0.5 text-xs dark:bg-zinc-800">https://reddit.jesspete.shop</code> via
          <code className="rounded bg-zinc-100 px-1 py-0.5 text-xs dark:bg-zinc-800">playwright.config.ts</code>. It was written using
          resilient role/text-based locators, but has <strong>not been executed against the live site</strong> in
          this environment (no browser runner available here) — run it yourself and expect to adjust a
          selector or two on the first pass.
        </p>
        <div className="rounded-lg bg-zinc-900 p-3 font-mono text-xs text-zinc-100 dark:bg-black">
          {commands.map((c) => (
            <div key={c} className="flex gap-2">
              <span className="select-none text-zinc-500">$</span>
              <span>{c}</span>
            </div>
          ))}
        </div>
        <ul className="list-disc space-y-1 pl-5 text-xs">
          <li>auth.spec.ts — AUTH-1, AUTH-2, AUTH-3, AUTH-5</li>
          <li>navigation.spec.ts — NAV-1, NAV-3, NAV-4</li>
          <li>feed-and-voting.spec.ts — FEED-1, FEED-5, VOTE-1, VOTE-2</li>
          <li>comments.spec.ts — COM-1, COM-7, COM-8</li>
          <li>accessibility-and-responsive.spec.ts — A11Y-1, A11Y-3, RESP-1</li>
        </ul>
      </div>
    </section>
  );
}
