import { ClipboardCheck } from "lucide-react";
import { staticFindings } from "../data/staticFindings";
import { SeverityBadge } from "./StatusBadge";

export function StaticFindings() {
  return (
    <section className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
      <div className="flex items-center gap-2 border-b border-zinc-100 px-4 py-3 dark:border-zinc-800">
        <ClipboardCheck className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
        <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
          Verified findings from static inspection
        </h3>
        <span className="ml-auto rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400">
          Confidence: Verified
        </span>
      </div>
      <ul className="divide-y divide-zinc-100 dark:divide-zinc-800/60">
        {staticFindings.map((f) => (
          <li key={f.id} className="px-4 py-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[11px] text-zinc-400 dark:text-zinc-500">{f.id}</span>
              <SeverityBadge severity={f.severity} />
              <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">{f.title}</p>
            </div>
            <p className="mt-1.5 text-xs text-zinc-600 dark:text-zinc-400">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Evidence:</span> {f.evidence}
            </p>
            <p className="mt-1 text-xs text-zinc-600 dark:text-zinc-400">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Impact:</span> {f.impact}
            </p>
            <p className="mt-1 text-xs text-zinc-600 dark:text-zinc-400">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">Recommendation:</span> {f.recommendation}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}
