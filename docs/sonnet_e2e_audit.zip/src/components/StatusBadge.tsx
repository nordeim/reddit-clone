import { cn } from "../utils/cn";
import type { FindingSeverity, Priority, TestStatus } from "../types";

const priorityStyles: Record<Priority, string> = {
  critical: "bg-rose-500/10 text-rose-600 ring-rose-500/20 dark:text-rose-400",
  high: "bg-amber-500/10 text-amber-700 ring-amber-500/20 dark:text-amber-400",
  medium: "bg-sky-500/10 text-sky-700 ring-sky-500/20 dark:text-sky-400",
  low: "bg-zinc-500/10 text-zinc-600 ring-zinc-500/20 dark:text-zinc-400",
};

export function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ring-1 ring-inset",
        priorityStyles[priority],
      )}
    >
      {priority}
    </span>
  );
}

const severityStyles: Record<FindingSeverity, string> = {
  critical: "bg-rose-500/10 text-rose-600 ring-rose-500/20 dark:text-rose-400",
  high: "bg-amber-500/10 text-amber-700 ring-amber-500/20 dark:text-amber-400",
  medium: "bg-sky-500/10 text-sky-700 ring-sky-500/20 dark:text-sky-400",
  low: "bg-zinc-500/10 text-zinc-600 ring-zinc-500/20 dark:text-zinc-400",
  info: "bg-emerald-500/10 text-emerald-700 ring-emerald-500/20 dark:text-emerald-400",
};

export function SeverityBadge({ severity }: { severity: FindingSeverity }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ring-1 ring-inset",
        severityStyles[severity],
      )}
    >
      {severity}
    </span>
  );
}

const statusStyles: Record<TestStatus, string> = {
  "not-run": "bg-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:text-zinc-400",
  pass: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400",
  fail: "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-400",
  blocked: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400",
};

const statusLabels: Record<TestStatus, string> = {
  "not-run": "Not run",
  pass: "Pass",
  fail: "Fail",
  blocked: "Blocked",
};

export function StatusPill({ status }: { status: TestStatus }) {
  return (
    <span className={cn("inline-flex items-center rounded-md px-2 py-1 text-xs font-medium", statusStyles[status])}>
      {statusLabels[status]}
    </span>
  );
}
