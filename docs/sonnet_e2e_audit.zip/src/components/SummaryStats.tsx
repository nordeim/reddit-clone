import type { TestCase, TestStatus } from "../types";

interface SummaryStatsProps {
  cases: TestCase[];
  getStatus: (id: string) => TestStatus;
}

export function SummaryStats({ cases, getStatus }: SummaryStatsProps) {
  const total = cases.length;
  const counts = cases.reduce(
    (acc, c) => {
      acc[getStatus(c.id)] += 1;
      return acc;
    },
    { "not-run": 0, pass: 0, fail: 0, blocked: 0 } as Record<TestStatus, number>,
  );
  const criticalOpen = cases.filter(
    (c) => c.priority === "critical" && getStatus(c.id) !== "pass",
  ).length;

  const tiles: Array<{ label: string; value: number; tone: string }> = [
    { label: "Total cases", value: total, tone: "text-zinc-900 dark:text-zinc-100" },
    { label: "Passed", value: counts.pass, tone: "text-emerald-600 dark:text-emerald-400" },
    { label: "Failed", value: counts.fail, tone: "text-rose-600 dark:text-rose-400" },
    { label: "Blocked", value: counts.blocked, tone: "text-amber-600 dark:text-amber-400" },
    { label: "Not run", value: counts["not-run"], tone: "text-zinc-500 dark:text-zinc-400" },
    { label: "Critical still open", value: criticalOpen, tone: "text-rose-600 dark:text-rose-400" },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      {tiles.map((t) => (
        <div key={t.label} className="rounded-xl border border-zinc-200 bg-white p-3 dark:border-zinc-800 dark:bg-zinc-900">
          <p className={`text-2xl font-bold tabular-nums ${t.tone}`}>{t.value}</p>
          <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">{t.label}</p>
        </div>
      ))}
    </div>
  );
}
