import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "../utils/cn";
import type { FeatureArea, TestCase, TestStatus } from "../types";
import { PriorityBadge, StatusPill } from "./StatusBadge";

interface FeatureGroupProps {
  area: FeatureArea;
  cases: TestCase[];
  getStatus: (id: string) => TestStatus;
  setStatus: (id: string, status: TestStatus) => void;
}

const statusCycle: TestStatus[] = ["not-run", "pass", "fail", "blocked"];

export function FeatureGroup({ area, cases, getStatus, setStatus }: FeatureGroupProps) {
  const [open, setOpen] = useState(true);
  const passCount = cases.filter((c) => getStatus(c.id) === "pass").length;

  return (
    <section className="rounded-xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
      >
        <div className="flex items-center gap-2">
          <ChevronDown className={cn("h-4 w-4 shrink-0 text-zinc-400 transition-transform", !open && "-rotate-90")} aria-hidden="true" />
          <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">{area}</h3>
        </div>
        <span className="shrink-0 rounded-full bg-zinc-100 px-2 py-0.5 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
          {passCount}/{cases.length} passed
        </span>
      </button>
      {open && (
        <ul className="divide-y divide-zinc-100 border-t border-zinc-100 dark:divide-zinc-800/60 dark:border-zinc-800">
          {cases.map((c) => {
            const status = getStatus(c.id);
            return (
              <li key={c.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] text-zinc-400 dark:text-zinc-500">{c.id}</span>
                    <PriorityBadge priority={c.priority} />
                    <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">{c.title}</p>
                  </div>
                  <ol className="mt-1.5 list-decimal space-y-0.5 pl-5 text-xs text-zinc-500 dark:text-zinc-400">
                    {c.steps.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ol>
                  <p className="mt-1.5 text-xs text-zinc-700 dark:text-zinc-300">
                    <span className="font-semibold">Expected:</span> {c.expected}
                  </p>
                  {c.notes && (
                    <p className="mt-1 text-xs italic text-zinc-500 dark:text-zinc-500">{c.notes}</p>
                  )}
                </div>
                <div className="flex shrink-0 items-center gap-2 sm:flex-col sm:items-end">
                  <StatusPill status={status} />
                  <button
                    type="button"
                    onClick={() => {
                      const next = statusCycle[(statusCycle.indexOf(status) + 1) % statusCycle.length];
                      setStatus(c.id, next);
                    }}
                    className="rounded-md border border-zinc-300 px-2 py-1 text-xs font-medium text-zinc-600 transition-colors hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
                  >
                    Mark next →
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
