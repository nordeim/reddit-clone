import { Flame, Moon, Sun } from "lucide-react";

interface TopBarProps {
  dark: boolean;
  onToggleDark: () => void;
}

export function TopBar({ dark, onToggleDark }: TopBarProps) {
  return (
    <header className="sticky top-0 z-20 border-b border-zinc-200 bg-white/90 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/90">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-500 text-white shadow-sm">
            <Flame className="h-5 w-5" strokeWidth={2.25} />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-bold tracking-tight text-zinc-900 dark:text-zinc-50">
              Embers QA Console
            </p>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">E2E test plan &amp; findings</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="https://reddit.jesspete.shop/"
            target="_blank"
            rel="noreferrer"
            className="hidden rounded-md border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 sm:inline-flex dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
          >
            Open target site ↗
          </a>
          <button
            type="button"
            onClick={onToggleDark}
            aria-pressed={dark}
            aria-label={dark ? "Switch to light theme" : "Switch to dark theme"}
            className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-zinc-300 text-zinc-600 transition-colors hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
          >
            {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>
      </div>
    </header>
  );
}


