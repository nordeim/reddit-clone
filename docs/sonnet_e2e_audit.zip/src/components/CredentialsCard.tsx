import { KeyRound } from "lucide-react";

const fields: Array<{ label: string; value: string }> = [
  { label: "Username", value: "you" },
  { label: "Password", value: "embers-demo" },
  { label: "Display Name", value: "You" },
  { label: "User ID", value: "u-me" },
];

export function CredentialsCard() {
  return (
    <div className="rounded-xl border border-zinc-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
      <div className="mb-3 flex items-center gap-2">
        <KeyRound className="h-4 w-4 text-orange-600 dark:text-orange-400" aria-hidden="true" />
        <h2 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">Test account (demo)</h2>
      </div>
      <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
        {fields.map((f) => (
          <div key={f.label} className="col-span-2 grid grid-cols-2 items-baseline border-b border-dashed border-zinc-100 pb-1.5 last:border-0 dark:border-zinc-800">
            <dt className="text-zinc-500 dark:text-zinc-400">{f.label}</dt>
            <dd className="justify-self-end font-mono text-xs text-zinc-800 dark:text-zinc-200">{f.value}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-3 text-xs text-zinc-500 dark:text-zinc-500">
        Provided demo/test credential — used only against the target QA environment, never logged or sent
        anywhere by this console.
      </p>
    </div>
  );
}
