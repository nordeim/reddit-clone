import { Download, RotateCcw } from "lucide-react";
import type { TestCase, TestStatus } from "../types";

interface ExportBarProps {
  cases: TestCase[];
  getStatus: (id: string) => TestStatus;
  onReset: () => void;
}

function download(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function ExportBar({ cases, getStatus, onReset }: ExportBarProps) {
  const exportJson = () => {
    const payload = cases.map((c) => ({
      id: c.id,
      area: c.area,
      title: c.title,
      priority: c.priority,
      status: getStatus(c.id),
    }));
    download("embers-qa-results.json", JSON.stringify(payload, null, 2), "application/json");
  };

  const exportCsv = () => {
    const header = "id,area,title,priority,status\n";
    const rows = cases
      .map((c) => {
        const title = c.title.replace(/"/g, '""');
        return `${c.id},"${c.area}","${title}",${c.priority},${getStatus(c.id)}`;
      })
      .join("\n");
    download("embers-qa-results.csv", header + rows, "text/csv");
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        onClick={exportJson}
        className="inline-flex items-center gap-1.5 rounded-md border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
      >
        <Download className="h-3.5 w-3.5" aria-hidden="true" /> Export JSON
      </button>
      <button
        type="button"
        onClick={exportCsv}
        className="inline-flex items-center gap-1.5 rounded-md border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 dark:border-zinc-700 dark:text-zinc-200 dark:hover:bg-zinc-800"
      >
        <Download className="h-3.5 w-3.5" aria-hidden="true" /> Export CSV
      </button>
      <button
        type="button"
        onClick={() => {
          if (window.confirm("Reset all recorded test statuses back to Not run?")) onReset();
        }}
        className="ml-auto inline-flex items-center gap-1.5 rounded-md border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-500 transition-colors hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 dark:border-zinc-700 dark:text-zinc-400 dark:hover:bg-zinc-800"
      >
        <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> Reset run
      </button>
    </div>
  );
}
