import { Search } from "lucide-react";
import type { FeatureArea, Priority, TestStatus } from "../types";

interface FiltersProps {
  areas: FeatureArea[];
  area: FeatureArea | "all";
  onAreaChange: (v: FeatureArea | "all") => void;
  priority: Priority | "all";
  onPriorityChange: (v: Priority | "all") => void;
  status: TestStatus | "all";
  onStatusChange: (v: TestStatus | "all") => void;
  query: string;
  onQueryChange: (v: string) => void;
}

export function Filters({
  areas,
  area,
  onAreaChange,
  priority,
  onPriorityChange,
  status,
  onStatusChange,
  query,
  onQueryChange,
}: FiltersProps) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-zinc-200 bg-white p-3 sm:flex-row sm:items-center dark:border-zinc-800 dark:bg-zinc-900">
      <div className="relative flex-1">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400" aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search test cases (id, title, step text)…"
          aria-label="Search test cases"
          className="w-full rounded-md border border-zinc-300 bg-zinc-50 py-1.5 pl-8 pr-3 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-orange-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-100 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100 dark:placeholder:text-zinc-500 dark:focus:bg-zinc-900 dark:focus:ring-orange-500/20"
        />
      </div>
      <label className="flex items-center gap-2 text-sm">
        <span className="sr-only">Filter by feature area</span>
        <select
          value={area}
          onChange={(e) => onAreaChange(e.target.value as FeatureArea | "all")}
          className="rounded-md border border-zinc-300 bg-zinc-50 px-2 py-1.5 text-sm text-zinc-700 focus:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-100 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-200 dark:focus:ring-orange-500/20"
        >
          <option value="all">All areas</option>
          {areas.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </select>
      </label>
      <label className="flex items-center gap-2 text-sm">
        <span className="sr-only">Filter by priority</span>
        <select
          value={priority}
          onChange={(e) => onPriorityChange(e.target.value as Priority | "all")}
          className="rounded-md border border-zinc-300 bg-zinc-50 px-2 py-1.5 text-sm text-zinc-700 focus:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-100 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-200 dark:focus:ring-orange-500/20"
        >
          <option value="all">All priorities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </label>
      <label className="flex items-center gap-2 text-sm">
        <span className="sr-only">Filter by status</span>
        <select
          value={status}
          onChange={(e) => onStatusChange(e.target.value as TestStatus | "all")}
          className="rounded-md border border-zinc-300 bg-zinc-50 px-2 py-1.5 text-sm text-zinc-700 focus:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-100 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-200 dark:focus:ring-orange-500/20"
        >
          <option value="all">All statuses</option>
          <option value="not-run">Not run</option>
          <option value="pass">Pass</option>
          <option value="fail">Fail</option>
          <option value="blocked">Blocked</option>
        </select>
      </label>
    </div>
  );
}
